https://www.svgrepo.com/collection/middle-age-monocolor/
